package com.example.admin.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.example.admin.myapplication.profile.ProfileUser;

public class Choose_Topic extends AppCompatActivity {
    ImageButton ImageButtonReport;
    ImageButton ImageButtonProfile;
    ImageButton ImageButtonLogout;
    private View.OnClickListener ImageButtonReportOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent beach = new  Intent(Choose_Topic.this, HomeApp.class);
            startActivity(beach);

        }
    };
    private View.OnClickListener ImageButtonProfileOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent beach = new  Intent(Choose_Topic.this, ProfileUser.class);
            startActivity(beach);

        }
    };
    private View.OnClickListener ImageButtonLogoutOnClickListener = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            Intent beach = new  Intent(Choose_Topic.this, MainActivity.class);
            startActivity(beach);

    }};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose__topic);
        ImageButtonReport = (ImageButton) findViewById(R.id.imgButtonReport);
        ImageButtonProfile = (ImageButton)findViewById(R.id.imgButtonProfile);
        ImageButtonLogout = (ImageButton)findViewById(R.id.imgButtonLogout);
        ImageButtonReport.setOnClickListener(ImageButtonReportOnClickListener);
        ImageButtonProfile.setOnClickListener(ImageButtonProfileOnClickListener);
        ImageButtonLogout.setOnClickListener(ImageButtonLogoutOnClickListener);

    }

    @Override
    public void onBackPressed(){

    }
}
