package com.example.admin.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.StringBuilderPrinter;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.MediaStore.Images.Media;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.admin.myapplication.domain.SpinerItem;
import com.example.admin.myapplication.domain.request.LoginRequestModel;
import com.example.admin.myapplication.domain.request.SubmitProblemRequestModel;
import com.example.admin.myapplication.domain.response.LoginResponseModel;
import com.example.admin.myapplication.domain.response.SubmitProblemResponseModel;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeApp extends AppCompatActivity {
    public static final int REQUEST_CAMERA = 2;

    private Spinner buildingSpinner;
    private Spinner titleProblemSpinner;

    private Button cameraButton;
    private Button submitProblemButton;

    private EditText problemDetailEditText;
    private EditText locationDetailEditText;

    private ImageView problemImageView;

    private OneShotService oneShotService;

    private View.OnClickListener captureImageOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent  = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent, 123);
        }
    };

    private View.OnClickListener submitProblemOnClickEventListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            SharedPreferences pref = ApiUtils.getSharedPreference(getApplicationContext());

            Bitmap bm = ((BitmapDrawable) problemImageView.getDrawable()).getBitmap();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            String encodedImage = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);

            String titleProblem = ((SpinerItem) titleProblemSpinner.getSelectedItem()).getKey();
            String problemDetail = problemDetailEditText.getText().toString();
            String building = ((SpinerItem) buildingSpinner.getSelectedItem()).getKey();
            String locationDetail = locationDetailEditText.getText().toString();

            SubmitProblemRequestModel submitProblemRequestModel = new SubmitProblemRequestModel();

            submitProblemRequestModel.setStudentCode(pref.getString("studentCode", ""));
            submitProblemRequestModel.setProblemTitle(titleProblem);
            submitProblemRequestModel.setProblemDetail(problemDetail);
            submitProblemRequestModel.setBuilding(building);
            submitProblemRequestModel.setLocationDetail(locationDetail);
            submitProblemRequestModel.setProblemImage(encodedImage);

            doSubmitProblem(submitProblemRequestModel);

        }
    };

    public void doSubmitProblem(final SubmitProblemRequestModel submitProblemRequestModel) {

        Log.v("submitRequestModel", submitProblemRequestModel.toString());

        oneShotService.doSubmitProblem(submitProblemRequestModel).enqueue(new Callback<SubmitProblemResponseModel>() {
            @Override
            public void onResponse(Call<SubmitProblemResponseModel> call, Response<SubmitProblemResponseModel> response) {

                if(response.isSuccessful()) {

                    SubmitProblemResponseModel submitProblemResponseModel = response.body();

                    if(SubmitProblemResponseModel.STATUS_SUCCESS.equals(submitProblemResponseModel.getStatus())) {
                        Toast.makeText(getApplicationContext(), submitProblemResponseModel.getDescription(), Toast.LENGTH_LONG).show();

                        Intent go = new Intent(getApplicationContext(), Fill.class);
                        startActivity(go);
                    } else {
                        Toast.makeText(getApplicationContext(), submitProblemResponseModel.getDescription(), Toast.LENGTH_LONG).show();
                    }

                }else {
                    int statusCode  = response.code();
                    Toast.makeText(getApplicationContext(), "Failed with http code: " + statusCode + ", body: " + response.body(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<SubmitProblemResponseModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Failed to connected to server: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.app_home);

        List<SpinerItem> buildingList = new ArrayList<SpinerItem>();

        buildingList.add(new SpinerItem("ตึก 1", "ตึก1"));
        buildingList.add(new SpinerItem("ตึก 3", "ตึก3"));
        buildingList.add(new SpinerItem("ตึก 4", "ตึก4"));
        buildingList.add(new SpinerItem("ตึก 5", "ตึก5"));
        buildingList.add(new SpinerItem("ตึก 6", "ตึก6"));
        buildingList.add(new SpinerItem("ตึก 7", "ตึก7"));
        buildingList.add(new SpinerItem("ตึก 8", "ตึก8"));
        buildingList.add(new SpinerItem("ตึก 9", "ตึก9"));
        buildingList.add(new SpinerItem("ตึก 10", "ตึก10"));
        buildingList.add(new SpinerItem("ตึก 11", "ตึก11"));
        buildingList.add(new SpinerItem("ตึก 14", "ตึก14"));
        buildingList.add(new SpinerItem("ตึก 15", "ตึก15"));
        buildingList.add(new SpinerItem("ตึก 16", "ตึก16"));
        buildingList.add(new SpinerItem("ตึก 17", "ตึก17"));
        buildingList.add(new SpinerItem("ตึก 18", "ตึก18"));
        buildingList.add(new SpinerItem("ตึก 19", "ตึก19"));
        buildingList.add(new SpinerItem("ตึก 20", "ตึก20"));
        buildingList.add(new SpinerItem("ตึก 21", "ตึก21"));
        buildingList.add(new SpinerItem("ตึก 22", "ตึก22"));
        buildingList.add(new SpinerItem("ตึก 23", "ตึก23"));
        buildingList.add(new SpinerItem("ตึก 24", "ตึก24"));

        ArrayAdapter<SpinerItem> dataAdapter = new ArrayAdapter<SpinerItem>(this, android.R.layout.simple_spinner_item, buildingList);

        buildingSpinner = (Spinner) this.findViewById(R.id.spinner_building);
        buildingSpinner.setAdapter(dataAdapter);

        titleProblemSpinner = (Spinner)this.findViewById(R.id.titleProblemSpinner);

        List<SpinerItem> problemList = new ArrayList<SpinerItem>();

        problemList.add(new SpinerItem("อุปกรณ์ชำรุด","อุปกรณ์ชำรุด"));
        problemList.add(new SpinerItem("อาคารสถานที","อาคารสถานที่"));
        problemList.add(new SpinerItem("ความสะอาด","ความสะอาด"));

        ArrayAdapter<SpinerItem> problemAdapter = new ArrayAdapter<SpinerItem>(this, android.R.layout.simple_spinner_item, problemList);

        titleProblemSpinner.setAdapter(problemAdapter);

        cameraButton = (Button) this.findViewById(R.id.cameraButton);
        cameraButton.setOnClickListener(captureImageOnClickListener);

        submitProblemButton = (Button) this.findViewById(R.id.submitProblemButton);

        submitProblemButton.setOnClickListener(submitProblemOnClickEventListener);

        problemDetailEditText = (EditText) this.findViewById(R.id.problemDetailEditText);
        locationDetailEditText = (EditText) this.findViewById(R.id.locationDetailEditText);

        oneShotService = ApiUtils.getOneShotService();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode, data);

        Bundle extras = data.getExtras();
        Bitmap bitmap = (Bitmap)extras.get("data");
        problemImageView = (ImageView)findViewById(R.id.imageView_photo);
        problemImageView.setImageBitmap(bitmap);
    }
}

