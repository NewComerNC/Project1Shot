package com.example.admin.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class Fill extends AppCompatActivity {
    private Button btn_back;
    private View.OnClickListener ButtonBackHome = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent st = new Intent(Fill.this, Choose_Topic.class);
            startActivity(st);
        }
    };

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_fill);

            btn_back = (Button) findViewById(R.id.btn_back_home);
            btn_back.setOnClickListener(ButtonBackHome);
        }

    @Override
    public void onBackPressed(){

    }
    }
