package com.example.admin.myapplication.domain.response;

public class SubmitProblemResponseModel extends AbstractResponseModel {


}


