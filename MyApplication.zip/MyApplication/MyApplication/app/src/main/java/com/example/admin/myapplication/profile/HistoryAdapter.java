package com.example.admin.myapplication.profile;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.admin.myapplication.R;
import com.example.admin.myapplication.domain.response.Problem;

import java.util.List;

public class HistoryAdapter extends BaseAdapter {

    private List<Problem> mList;

    public void setList(List<Problem> list) {
        this.mList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        if (mList == null) {
            return 0;
        } else {
            return mList.size();
        }
    }

    @Override
    public Problem getItem(int position) {
        if (mList == null) {
            return null;
        } else {
            try {
                return mList.get(position);
            } catch (IndexOutOfBoundsException ignore) {
                return null;
            }
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final Context context = parent.getContext();
        final ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context)
                    .inflate(R.layout.view_history, parent, false);
            holder = new ViewHolder();
            holder.vStatus = convertView.findViewById(R.id.vStatus);
            holder.tvDate = convertView.findViewById(R.id.tvDate);
            holder.tvProblemType = convertView.findViewById(R.id.tvProblemType);
            holder.tvProblemDetail = convertView.findViewById(R.id.tvProblemDetail);
            holder.tvLocation = convertView.findViewById(R.id.tvLocation);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        final Problem history = getItem(position);
        if (history != null) {
            final String status = history.getStatusp();
            int statusBackgroundDrawable = R.drawable.bg_circle_yellow;
            if ("1".equals(status)) {
                statusBackgroundDrawable = R.drawable.bg_circle_green;
            }
            holder.vStatus.setBackground(ContextCompat.getDrawable(context, statusBackgroundDrawable));
            holder.tvDate.setText(history.getDateTime());
            holder.tvProblemType.setText(history.getProblemType());
            holder.tvProblemDetail.setText(history.getProblemDetail());
            holder.tvLocation.setText(history.getLocation());
        }
        return convertView;
    }

    private class ViewHolder {

        private View vStatus;
        private TextView tvDate;
        private TextView tvProblemType;
        private TextView tvProblemDetail;
        private TextView tvLocation;

    }

}
