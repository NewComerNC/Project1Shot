package com.example.admin.myapplication.domain.response;

public class LoginResponseModel extends AbstractResponseModel {

    private String studentCode;

    public String getStudentCode() {
        return studentCode;
    }

    public void setStudentCode(String studentCode) {
        this.studentCode = studentCode;
    }
}
