package com.example.admin.myapplication.domain.response;

import com.google.gson.annotations.SerializedName;

public class Problem {

    @SerializedName("statusp")
    private String statusp;

    @SerializedName("date_time")
    private String dateTime;

    @SerializedName("problem_detail")
    private String problemDetail;

    @SerializedName("problem_type")
    private String problemType;

    @SerializedName("location")
    private String location;

    public String getStatusp() {
        return statusp;
    }

    public String getDateTime() {
        return dateTime;
    }

    public String getProblemDetail() {
        return problemDetail;
    }

    public String getProblemType() {
        return problemType;
    }

    public String getLocation() {
        return location;
    }

}