package com.example.admin.myapplication;

import com.example.admin.myapplication.domain.request.LoginRequestModel;
import com.example.admin.myapplication.domain.request.SubmitProblemRequestModel;
import com.example.admin.myapplication.domain.response.LoginResponseModel;
import com.example.admin.myapplication.domain.response.Problem;
import com.example.admin.myapplication.domain.response.Profile;
import com.example.admin.myapplication.domain.response.SubmitProblemResponseModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface OneShotService {

    @POST("androidLogin.php")
    @Headers("Content-Type: application/json")
    Call<LoginResponseModel> doLogin(@Body LoginRequestModel loginRequestModel);

    @POST("submitProblem.php")
    @Headers("Content-Type: application/json")
    Call<SubmitProblemResponseModel> doSubmitProblem(@Body SubmitProblemRequestModel submitProblemRequestModel);

    @GET("get-userprofile.php")
    Call<Profile> getUserProfile(@Query("user_id") String userId);

    @GET("get-problem.php")
    Call<List<Problem>> getProblem(@Query("user_id") String userId);

}
