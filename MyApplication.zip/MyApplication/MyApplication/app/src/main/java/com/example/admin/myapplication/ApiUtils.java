package com.example.admin.myapplication;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.admin.myapplication.domain.RetrofitClient;

public class ApiUtils {

    public static final String SHARED_PREFERENCE_NAME = "OneShotPref";

    public static final String BASE_URL = "http://1shot.xyz/ws/";

    public static OneShotService getOneShotService() {
        return RetrofitClient.getClient(BASE_URL).create(OneShotService.class);
    }

    public static SharedPreferences.Editor getSharedPreferenceEditor(Context applicationContext) {

        SharedPreferences pref = applicationContext.getSharedPreferences(SHARED_PREFERENCE_NAME, 0); // 0 - for private mode
        SharedPreferences.Editor editor = pref.edit();

        return editor;
    }

    public static SharedPreferences getSharedPreference(Context applicationContext) {
        SharedPreferences pref = applicationContext.getSharedPreferences(SHARED_PREFERENCE_NAME, 0); // 0 - for private mode
        return pref;
    }

    public static String getStudentCode(
            final Context context
    ) {
        return ApiUtils.getSharedPreference(context)
                .getString("studentCode", null);
    }

}
