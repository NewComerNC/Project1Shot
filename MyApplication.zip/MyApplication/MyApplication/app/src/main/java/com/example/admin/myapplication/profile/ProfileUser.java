package com.example.admin.myapplication.profile;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.example.admin.myapplication.ApiUtils;
import com.example.admin.myapplication.R;
import com.example.admin.myapplication.domain.response.Problem;
import com.example.admin.myapplication.domain.response.Profile;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileUser extends AppCompatActivity {

    private Call<Profile> mCallGetUserProfileWebService;

    private HistoryAdapter mAdapter = new HistoryAdapter();
    private Call<List<Problem>> mCallGetProblemWebService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_user);
        setupViews();
        callGetUserProfileWebService(getId());
        callGetProblemWebService(getId());
    }

    private void setupViews() {
        setupIdText();
        setupProblemList();
    }

    private void setupIdText() {
        ((TextView) findViewById(R.id.tvId2)).setText(getId());
    }

    private String getId() {
        return ApiUtils.getStudentCode(this);
    }

    private void setupProblemList() {
        ((ListView) findViewById(R.id.lvHistory)).setAdapter(mAdapter);
    }

    private void callGetUserProfileWebService(
            final String userId
    ) {
        mCallGetUserProfileWebService = ApiUtils.getOneShotService().getUserProfile(userId);
        mCallGetUserProfileWebService.enqueue(getCallbackGetUserProfileWebService());
    }

    private Callback<Profile> getCallbackGetUserProfileWebService() {
        return new Callback<Profile>() {
            @Override
            public void onResponse(Call<Profile> ignore, Response<Profile> response) {
                final Profile body = response.body();
                if (body != null) {
                    setFullName(body.getName());
                    setPoint(body.getPoint());
                }
            }

            @Override
            public void onFailure(Call<Profile> ignore, Throwable ignore2) {
            }
        };
    }

    private void setFullName(
            final String fullName
    ) {
        ((TextView) findViewById(R.id.tvFullName)).setText(fullName);
    }

    private void setPoint(
            final String point
    ) {
        ((TextView) findViewById(R.id.tvScore2)).setText(point);
    }

    private void callGetProblemWebService(
            final String userId
    ) {
        setProblemToList(null);
        mCallGetProblemWebService = ApiUtils.getOneShotService().getProblem(userId);
        mCallGetProblemWebService.enqueue(getCallbackGetProblemWebService());
    }

    private Callback<List<Problem>> getCallbackGetProblemWebService() {
        return new Callback<List<Problem>>() {
            @Override
            public void onResponse(Call<List<Problem>> ignore, Response<List<Problem>> response) {
                final List<Problem> body = response.body();
                if (body == null || body.isEmpty()) {
                    setNotFoundTextVisibility(true);
                } else {
                    setNotFoundTextVisibility(false);
                    setProblemToList(body);
                }
            }

            @Override
            public void onFailure(Call<List<Problem>> ignore, Throwable ignore2) {

            }
        };
    }

    private void setProblemToList(final List<Problem> problems) {
        if (mAdapter != null) {
            mAdapter.setList(problems);
        }
    }

    private void setNotFoundTextVisibility(
            final boolean visible
    ) {
        if (visible) {
            findViewById(R.id.tvNotFound).setVisibility(View.VISIBLE);
        } else {
            findViewById(R.id.tvNotFound).setVisibility(View.GONE);
        }
    }

    @Override
    protected void onDestroy() {
        destroyCallGetUserProfileWebService();
        destroyCallGetProblemWebService();
        super.onDestroy();
    }

    private void destroyCallGetUserProfileWebService() {
        if (mCallGetUserProfileWebService != null &&
                !mCallGetUserProfileWebService.isCanceled()) {
            mCallGetUserProfileWebService.cancel();
        }
    }

    private void destroyCallGetProblemWebService() {
        if (mCallGetProblemWebService != null &&
                !mCallGetProblemWebService.isCanceled()) {
            mCallGetProblemWebService.cancel();
        }
    }

}
