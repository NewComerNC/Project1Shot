package com.example.admin.myapplication.domain.response;

import com.google.gson.annotations.SerializedName;

public class Profile {

    @SerializedName("name")
    private String name;

    @SerializedName("point")
    private String point;

    public String getName() {
        return name;
    }

    public String getPoint() {
        return point;
    }

}