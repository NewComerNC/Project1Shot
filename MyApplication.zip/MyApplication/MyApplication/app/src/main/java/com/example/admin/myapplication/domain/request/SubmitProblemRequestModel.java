package com.example.admin.myapplication.domain.request;

public class SubmitProblemRequestModel {

    private String studentCode;

    private String problemTitle;

    private String problemDetail;

    private String building;

    private String locationDetail;

    private String problemImage;

    public String getStudentCode() {
        return studentCode;
    }

    public void setStudentCode(String studentCode) {
        this.studentCode = studentCode;
    }

    public String getProblemTitle() {
        return problemTitle;
    }

    public void setProblemTitle(String problemTitle) {
        this.problemTitle = problemTitle;
    }

    public String getProblemDetail() {
        return problemDetail;
    }

    public void setProblemDetail(String problemDetail) {
        this.problemDetail = problemDetail;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public String getLocationDetail() {
        return locationDetail;
    }

    public void setLocationDetail(String locationDetail) {
        this.locationDetail = locationDetail;
    }

    public String getProblemImage() {
        return problemImage;
    }

    public void setProblemImage(String problemImage) {
        this.problemImage = problemImage;
    }

    @Override
    public String toString() {
        return "SubmitProblemRequestModel{" +
                "studentCode='" + studentCode + '\'' +
                ", problemTitle='" + problemTitle + '\'' +
                ", problemDetail='" + problemDetail + '\'' +
                ", building='" + building + '\'' +
                ", locationDetail='" + locationDetail + '\'' +
                ", problemImage='" + problemImage + '\'' +
                '}';
    }
}
