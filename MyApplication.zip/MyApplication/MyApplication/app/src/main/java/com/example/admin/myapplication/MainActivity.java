package com.example.admin.myapplication;

import android.content.Intent;
        import android.content.SharedPreferences;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Toast;

        import com.example.admin.myapplication.domain.request.LoginRequestModel;
        import com.example.admin.myapplication.domain.response.LoginResponseModel;

        import retrofit2.Call;
        import retrofit2.Callback;
        import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private Button signInButton;

    private EditText userEditText;

    private EditText passwordEditText;

    private OneShotService oneShotService;

    private View.OnClickListener signInOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            String userName = userEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            LoginRequestModel loginRequestModel = new LoginRequestModel();

            loginRequestModel.setUsername(userName);
            loginRequestModel.setPassword(password);

            doLogin(loginRequestModel);
        }
    };

    public void doLogin(final LoginRequestModel loginRequestModel) {
        oneShotService.doLogin(loginRequestModel).enqueue(new Callback<LoginResponseModel>() {
            @Override
            public void onResponse(Call<LoginResponseModel> call, Response<LoginResponseModel> response) {

                if(response.isSuccessful()) {

                    LoginResponseModel loginResponseModel = response.body();

                    if(LoginResponseModel.STATUS_SUCCESS.equals(loginResponseModel.getStatus())) {
                        Toast.makeText(getApplicationContext(), loginResponseModel.getDescription(), Toast.LENGTH_LONG).show();

                        SharedPreferences.Editor editor = ApiUtils.getSharedPreferenceEditor(getApplicationContext());

                        editor.putString("studentCode", loginRequestModel.getUsername());
                        editor.commit();

                        Intent go = new Intent(getApplicationContext(), Choose_Topic.class);
                        startActivity(go);
                    }

                    else {
                        Toast.makeText(getApplicationContext(), loginResponseModel.getDescription(), Toast.LENGTH_LONG).show();
                    }
                }else {
                    int statusCode  = response.code();
                    Toast.makeText(getApplicationContext(), "Failed with http code: " + statusCode + ", body: " + response.body(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponseModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Failed to connected to server: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        oneShotService = ApiUtils.getOneShotService();

        signInButton = (Button) findViewById(R.id.btn_sign);
        userEditText = (EditText) findViewById(R.id.edit_id);
        passwordEditText = (EditText) findViewById(R.id.edit_pass);

        signInButton.setOnClickListener(signInOnClickListener);
    }
}